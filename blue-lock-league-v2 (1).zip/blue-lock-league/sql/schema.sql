-- BLUE LOCK LEAGUE / SUPABASE
-- Bu scripti Supabase SQL Editor'da tek seferde çalıştır.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  role text not null default 'viewer' check (role in ('admin','editor','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  logo_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  team_id uuid references public.teams(id) on delete set null,
  position text,
  number integer,
  bio text,
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  home_team_id uuid references public.teams(id) on delete set null,
  away_team_id uuid references public.teams(id) on delete set null,
  home_score integer not null default 0,
  away_score integer not null default 0,
  status text not null default 'FULL TIME',
  played_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.match_events (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  event_type text not null check (event_type in ('goal','assist','match_up','critical_intervention')),
  minute integer,
  description text,
  created_at timestamptz not null default now()
);

create or replace view public.player_stats as
select
  p.id,
  p.name,
  p.position,
  p.number,
  p.bio,
  p.image_url,
  t.name as team_name,
  coalesce(count(*) filter (where e.event_type='goal'),0)::int as goals,
  coalesce(count(*) filter (where e.event_type='assist'),0)::int as assists,
  coalesce(count(*) filter (where e.event_type='match_up'),0)::int as match_ups,
  coalesce(count(*) filter (where e.event_type='critical_intervention'),0)::int as critical_interventions
from public.players p
left join public.teams t on t.id=p.team_id
left join public.match_events e on e.player_id=p.id
group by p.id,p.name,p.position,p.number,p.bio,p.image_url,t.name;

create or replace view public.matches_with_teams as
select
  m.id,m.home_score,m.away_score,m.status,m.played_at,
  ht.name as home_team_name,
  at.name as away_team_name
from public.matches m
left join public.teams ht on ht.id=m.home_team_id
left join public.teams at on at.id=m.away_team_id;


create or replace view public.match_events_with_players as
select
  e.id,e.match_id,e.player_id,e.event_type,e.minute,e.description,e.created_at,
  p.name as player_name
from public.match_events e
join public.players p on p.id=e.player_id;

-- RLS
alter table public.profiles enable row level security;
alter table public.teams enable row level security;
alter table public.players enable row level security;
alter table public.matches enable row level security;
alter table public.match_events enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin');
$$;

create policy "public read teams" on public.teams for select using (true);
create policy "public read players" on public.players for select using (true);
create policy "public read matches" on public.matches for select using (true);
create policy "public read events" on public.match_events for select using (true);
create policy "admins manage teams" on public.teams for all using (public.is_admin()) with check (public.is_admin());
create policy "admins manage players" on public.players for all using (public.is_admin()) with check (public.is_admin());
create policy "admins manage matches" on public.matches for all using (public.is_admin()) with check (public.is_admin());
create policy "admins manage events" on public.match_events for all using (public.is_admin()) with check (public.is_admin());
create policy "users read own profile" on public.profiles for select using (auth.uid()=id);
create policy "admins read profiles" on public.profiles for select using (public.is_admin());

-- AUTH kullanıcı oluşturduktan SONRA onun UUID'sini aşağıya yaz:
-- insert into public.profiles (id, username, role)
-- values ('USER_UUID_BURAYA', 'admin', 'admin')
-- on conflict (id) do update set role='admin';

-- Örnek takım/oyuncu:
insert into public.teams (name) values
('PXG'),('Bastard München'),('Ubers'),('Manshine City')
on conflict (name) do nothing;
