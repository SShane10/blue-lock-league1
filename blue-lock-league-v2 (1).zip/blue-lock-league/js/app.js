import { getPlayers, getMatches, money } from './data.js';
const players=await getPlayers(), matches=await getMatches();
const totalGoals=players.reduce((a,p)=>a+(p.goals||0),0);
const totalAssists=players.reduce((a,p)=>a+(p.assists||0),0);
const totalEvents=players.reduce((a,p)=>a+(p.goals||0)+(p.assists||0)+(p.match_ups||0)+(p.critical_interventions||0),0);
const totalValue=players.reduce((a,p)=>a+(p.market_value||0),0);
document.querySelector('#leagueStats').innerHTML=[
 ['OYUNCULAR',players.length,'Kayıtlı oyuncu'],
 ['GOLLER',totalGoals,'Toplam gol'],
 ['ASİSTLER',totalAssists,'Toplam asist'],
 ['LİG DEĞERİ',money(totalValue),'Toplam istatistik değeri']
].map(x=>`<div><span>${x[0]}</span><b>${x[1]}</b><small>${x[2]}</small></div>`).join('');
const top=[...players].sort((a,b)=>b.goals-a.goals).slice(0,3);
document.querySelector('#leaders').innerHTML=top.map((p,i)=>`<a class="leader" href="player.html?id=${p.id}"><strong>#${i+1} ${esc(p.name)}</strong><p>${esc(p.team_name||'')}</p><b>${p.goals} GOL</b></a>`).join('');
document.querySelector('#recentMatches').innerHTML=matches.slice(0,4).map(m=>`<article class="match-card"><div class="match-meta">${formatDate(m.played_at)} • ${m.status}</div><div class="match-teams"><div>${esc(m.home_team_name)}</div><b>${m.home_score} — ${m.away_score}</b><div>${esc(m.away_team_name)}</div></div></article>`).join('')||'<div class="empty">Henüz maç yok.</div>';
function formatDate(s){return s?new Date(s).toLocaleDateString('tr-TR',{day:'2-digit',month:'short',year:'numeric'}):'-'}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
