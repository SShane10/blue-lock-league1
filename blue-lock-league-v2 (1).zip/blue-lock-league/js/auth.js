import { getSupabase } from './supabase.js';

export async function signIn(email,password){
  const sb=await getSupabase();
  if(!sb) return {data:null,error:new Error('Önce js/config.js içine Supabase URL ve ANON KEY gir.')};
  return await sb.auth.signInWithPassword({email,password});
}
export async function logout(){const sb=await getSupabase(); if(sb) await sb.auth.signOut();}
export async function getSession(){const sb=await getSupabase(); if(!sb)return null; const {data}=await sb.auth.getSession(); return data.session;}
export async function requireAdmin(){
  const sb=await getSupabase();
  if(!sb){location.href='../login.html';return;}
  const {data:{user}}=await sb.auth.getUser();
  if(!user){location.href='../login.html';return;}
  const {data:profile,error}=await sb.from('profiles').select('role').eq('id',user.id).single();
  if(error || !profile || profile.role!=='admin'){document.body.innerHTML='<main class="page"><div class="empty">Bu hesabın admin yetkisi yok.</div></main>';return;}
}
