// Supabase bilgilerini buraya gir.
// GitHub Pages üzerinde gerçek admin sistemi için Supabase projesi oluşturup
// aşağıdaki iki değeri Project Settings > API bölümünden al.
//
// URL: https://xxxx.supabase.co
// ANON KEY: eyJ...

export const SUPABASE_URL = "YOUR_SUPABASE_URL";
export const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";

export const PRICE_RULES = {
  goal: 700000,
  assist: 600000,
  match_up: 100000,
  critical_intervention: 500000
};
