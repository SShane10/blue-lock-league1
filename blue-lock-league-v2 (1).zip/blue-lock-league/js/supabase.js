import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

let client = null;
export function isConfigured() {
  return SUPABASE_URL.startsWith('https://') && !SUPABASE_URL.includes('YOUR_') &&
         SUPABASE_ANON_KEY && !SUPABASE_ANON_KEY.includes('YOUR_');
}
export async function getSupabase() {
  if (!isConfigured()) return null;
  if (client) return client;
  const mod = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
  client = mod.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return client;
}
